const home = document.getElementById('home');

document.addEventListener('DOMContentLoaded', function() {
    setTimeout(() => {
        fadeIn(home); 
    }, 1000);
    
})

function fadeIn(element, duration = 1000) {
    element.style.display = '';
    element.style.opacity = 0;
    let last = +new Date();
    let tick = function () {
      element.style.opacity = +element.style.opacity + (new Date() - last) / duration;
      last = +new Date();
      if (+element.style.opacity < 1) {
        (window.requestAnimationFrame && requestAnimationFrame(tick)) || setTimeout(tick, 16);
      }
    };
    tick();
}

window.addEventListener('scroll', ()=>{
  let content = document.querySelector('#aboutImage');
  letContentPosition = content.getBoundingClientRect().top;
  let screenPosition = window.innerHeight/2;
  if(letContentPosition < screenPosition){
    content.classList.add('active');
  } else {
    content.classList.remove('active');
  }
});

window.addEventListener('scroll', ()=>{
  let content = document.querySelector('#aboutMe');
  letContentPosition = content.getBoundingClientRect().top;
  let screenPosition = window.innerHeight/1.1;
  if(letContentPosition < screenPosition){
    content.classList.add('active');
  } else {
    content.classList.remove('active');
  }
});

window.addEventListener('scroll', ()=>{
  let content = document.querySelector('#aboutDesc');
  letContentPosition = content.getBoundingClientRect().top;
  let screenPosition = window.innerHeight/1.1;
  if(letContentPosition < screenPosition){
    content.classList.add('active');
  } else {
    content.classList.remove('active');
  }
});

window.addEventListener('scroll', ()=>{
  let content = document.querySelector('#aboutContact');
  letContentPosition = content.getBoundingClientRect().top;
  let screenPosition = window.innerHeight/1.1;
  if(letContentPosition < screenPosition){
    content.classList.add('active');
  } else {
    content.classList.remove('active');
  }
});


window.addEventListener('scroll', ()=>{
  let content2 = document.querySelector('#education');
  letContentPosition = content2.getBoundingClientRect().top;
  let screenPosition = window.innerHeight;
  if(letContentPosition < screenPosition){
    content2.classList.add('active');
  } else {
    content2.classList.remove('active');
  }
});

window.addEventListener('scroll', ()=>{
  let content3 = document.querySelector('#experience');
  letContentPosition = content3.getBoundingClientRect().top;
  let screenPosition = window.innerHeight;
  if(letContentPosition < screenPosition){
    content3.classList.add('active');
  } else {
    content3.classList.remove('active');
  }
});

window.addEventListener('scroll', ()=>{
  let content3 = document.querySelector('#experience_');
  letContentPosition = content3.getBoundingClientRect().top;
  let screenPosition = window.innerHeight;
  if(letContentPosition < screenPosition){
    content3.classList.add('active');
  } else {
    content3.classList.remove('active');
  }
});

window.addEventListener('scroll', ()=>{
  let content3 = document.querySelector('#experience2');
  letContentPosition = content3.getBoundingClientRect().top;
  let screenPosition = window.innerHeight;
  if(letContentPosition < screenPosition){
    content3.classList.add('active');
  } else {
    content3.classList.remove('active');
  }
});

window.addEventListener('scroll', ()=>{
  let content3 = document.querySelector('#experience2_');
  letContentPosition = content3.getBoundingClientRect().top;
  let screenPosition = window.innerHeight;
  if(letContentPosition < screenPosition){
    content3.classList.add('active');
  } else {
    content3.classList.remove('active');
  }
});

window.addEventListener('scroll', ()=>{
  let content3 = document.querySelector('#experience3');
  letContentPosition = content3.getBoundingClientRect().top;
  let screenPosition = window.innerHeight;
  if(letContentPosition < screenPosition){
    content3.classList.add('active');
  } else {
    content3.classList.remove('active');
  }
});

window.addEventListener('scroll', ()=>{
  let content3 = document.querySelector('#experience3_');
  letContentPosition = content3.getBoundingClientRect().top;
  let screenPosition = window.innerHeight;
  if(letContentPosition < screenPosition){
    content3.classList.add('active');
  } else {
    content3.classList.remove('active');
  }
});


